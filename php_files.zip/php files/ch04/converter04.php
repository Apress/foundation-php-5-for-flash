<?php
// assign data incoming from Flash to simpler variables

$a = $_POST['value1'];
$b = $_POST['value2'];
$type = $_POST['conversionType'];
$units1 = $_POST['units1'];
$units2 = $_POST['units2'];

// select the appropriate conversion formula
switch($type) {
  // Area conversion
  case 'acreToHa':
    $r = $a * .405;
    $unitsR = 'hectares';
    break;
  case 'haToAcre':
    $r = $a * 2.471;
    $unitsR = 'acres';
    break;
  case 'sqftToM2':
    $r = $a * .0929;
    $unitsR = 'm�';
    break;
  case 'sqydToM2':
    $r = $a * .836;
    $unitsR = 'm�';
    break;
  case 'M2toSqft':
    $r = $a / .0929;
    $unitsR = 'sq ft';
    break;
  case 'M2toSqyd':
    $r = $a / .836;
    $unitsR = 'sq yd';
    break;
  
  // Length conversion
  case 'inToCm':
    $r = $a * 2.54;
    $unitsR = 'cm';
    break;
  case 'cmToIn':
    $r = $a / 2.54;
    $unitsR = 'in';
    break;
  case 'ftToM':
    $r = $a * .305;
    $unitsR = 'm';
    break;
  case 'ydToM':
    $r = $a * .914;
    $unitsR = 'm';
    break;

  // Temperature conversion
  case 'cToF':
    $r = ($a / 5) * 9 + 32;
    $unitsR = '�F';
    break;
  case 'fToC':
    $r = ($a - 32) / 9 * 5;
    $unitsR = '�C';
    break;
	
  // Capacity conversion
  case 'ptToLtr':
    $r = $a * .473;
    $r2 = $a * .568;
    $unitsUS = 'US pints';
    $unitsImp = 'Imperial pints';
    $unitsR = 'liters';
    break;
  case 'galToLtr':
    $r = $a * 3.785;
    $r2 = $a * 4.546;
    $unitsUS = 'US gallons';
    $unitsImp = 'Imperial gallons';
    $unitsR = 'liters';
    break;
  case 'ltrToPt':
    $r = $a / .473;
    $r2 = $a / .568;
    $unitsR = 'US pints';
    $unitsR2 = 'Imperial pints';
    break;
  case 'ltrToGal':
    $r = $a / 3.785;
    $r2 = $a / 4.546;
    $unitsR = 'US gallons';
    $unitsR2 = 'Imperial gallons';
    break;
  case 'UStoImp':
    $pints = $a * 8 + $b;
    $pints /= 1.201;
    $units1 = 'US gallons';
    $units2 = empty($a) ? 'US pints' : 'pints';
    $unitsR = 'Imperial gallons';
    $r = floor($pints / 8);
    $unitsR2 = $r ? 'pints' : 'Imperial pints';
    $r2 = $pints - ($r * 8);
    break;
  case 'ImpToUS':
    $pints = $a * 8 + $b;
    $pints *= 1.201;
    $units1 = 'Imperial gallons';
    $units2 = empty($a) ? 'Imperial pints' : 'pints';
    $unitsR = 'US gallons';
    $r = floor($pints / 8);
    $unitsR2 = $r ? 'pints' : 'US pints';
    $r2 = $pints - ($r * 8);
    break;

  // Weight conversion
  case 'lbToKg':
    $oz = $a * 16 + $b;
    $r = $oz / 16 * .454;
    $unitsR = 'kg';
    break;
  case 'kgToLb':
    $oz = $a / .454 * 16;
    $r = floor($oz / 16);
    $r2 = $oz % 16;
    $unitsR = 'lb';
    $unitsR2 = 'oz';
    break;
  case 'lbToSt':
    $r = floor($a / 14);
    $r2 = $a % 14;
    $unitsR = 'st';
    $unitsR2 = 'lb';
    break;
  case 'stToLb':
    $r = $a * 14 + $b;
    $unitsR = 'lb';
    break;

  }

// format the result for transfer to Flash
switch($type) {
  case 'ptToLtr':
  case 'galToLtr':
    // format the result for US pints/gallons to liters
    $output = plural($a, $unitsUS).' = '.plural(sprintf('%0.2f', $r), $unitsR)."\n";
	// format the result for Imperial pints/gallons to liters
    $output .= plural($a, $unitsImp).' = '.plural(sprintf('%0.2f', $r2), $unitsR);
    break;

  case 'ltrToPt':
  case 'ltrToGal':
    // format result of liters to US pints/gallons
    $output = plural($a, $units1).' = '.plural(sprintf('%0.2f', $r), $unitsR)."\n";
    // format result of Imperial equivalent
    $output .= 'or '.plural(sprintf('%0.2f', $r2), $unitsR2);
    break;

  case 'UStoImp':
  case 'ImpToUS':
    // check left and right input fields; if not empty, format result
	// if no input, return empty string for relevant field
    $output = (!empty($a)) ? plural($a, $units1).' ' : '';
    $output .= (!empty($b)) ? plural($b, $units2) : '';
	// output equals sign followed by new line character
    $output .= " =\n";
	// if $r (gallons) is not zero, format result
    $output .= $r ? plural($r, $unitsR).' ' : '';
	// format $r2 (pints)
    $output .= plural(sprintf('%0.2f',$r2), $unitsR2);
    break;

  case 'lbToKg':
  case 'stToLb':
    $output = (!empty($a)) ? plural($a, $units1).' ' : '';
    $output .= (!empty($b)) ? plural($b, $units2) : '';
    $output .= ' = ';
    $output .= $unitsR == 'lb' ? $r : sprintf('%0.3f', $r);
    $output .= ' '.$unitsR;
    break;

  case 'mToFt':
  case 'mToYd':
  case 'kgToLb':
  case 'lbToSt':
    $output = "$a $units1 = $r $unitsR $r2 $unitsR2";
  break;

  default:
    // format first unit for singular and plural values 
    $output = plural($a, $units1).' = ';
	// format second unit, adjust temperatures to one decimal place
	$output .= strpos($unitsR, '�') === 0 ? sprintf('%0.1f', $r).$unitsR : plural(sprintf('%0.2f',$r), $unitsR);
    }
// send the data back to Flash
echo 'output='.urlencode($output);

// remove final "s" from measurement unit if number 1 or less
function plural($number, $unit) {
  // if 0 or 1, and unit ends in "s"
  if (abs($number) <= 1 && strrpos($unit, 's') == (strlen($unit) - 1)) {
    // concatenate and remove final "s"
    return $number.' '.substr_replace($unit, '', -1);
    }
  else { // concatenate without changing
    return $number.' '.$unit;
    }
  }
?>