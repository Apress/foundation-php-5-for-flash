<?php
// function takes $myNum as an argument (parameter)
function doubleIt($myNum) {
  // inside the function, $myNum has no relationship
  // to the variable of the same name outside
  $myNum *= 2;
  // after multiplying the argument by 2
  // the result is returned as a new value
  return $myNum;
  }
// the version of $myNum outside the function
// has the same name, but the scope is different
$myNum = 3;
// the value of $myNum is 3
echo 'Before: '.$myNum.'<br />';
$doubled = doubleIt($myNum);
// the value of $myNum is still 3
echo 'After: '.$myNum.'<br />';
// the value of $doubled is the result of passing $myNum (3)
// to the doubleIt() function - 3 * 2 = 6
echo 'Doubled: '.$doubled;
?>