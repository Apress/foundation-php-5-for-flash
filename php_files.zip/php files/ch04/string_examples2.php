<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Getting the length of a string</title>
<style type="text/css">
body {font: 85% Arial, Helvetica, sans-serif;}
h1 {font-size: 150%; margin: 20px auto 15px 20px;}
p {width: 500px; margin: 10px 50px;}
#string {width: 250px;}
#answer {font-weight:bold; font-size:120%;margin: 20px 100px;}
</style>
</head>

<body>
<h1>Is this the ultimate answer?</h1>
<p>To get the length of a string with PHP, pass the string (or a string variable) to the function <strong>strlen()</strong>.</p>
<p>Capture the result in a variable for use elsewhere in a script. </p>
<form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <p>
    <strong>$answer = strlen('</strong>    <input name="string" type="text" id="string" value="
	<?php if(isset($_POST["string"])) echo $_POST["string"];
	else echo 'Flash is Life, the Universe and Everything'; ?>" /> 
    <strong>');</strong> </p>
  <p>
    <input type="submit" name="Submit" value="Get string length" />
  </p>
  <p id="answer"><?php if(isset($_POST["string"])) echo '$answer = '.strlen($_POST["string"]); ?></p>
</form>
</body>
</html>
