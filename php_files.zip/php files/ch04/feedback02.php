<?php
// if magic quotes turned on, remove slashes from escaped characters
if (get_magic_quotes_gpc()) {
  $_POST['from'] = stripslashes($_POST['from']);
  $_POST['snail'] = stripslashes($_POST['snail']);
  $_POST['comments'] = stripslashes($_POST['comments']);
  }

// initialize variables for validating input
$valid = true;
$reason1 = '';
$reason2 = '';
// strip whitespace from both sides of sender's name
$_POST['from'] = trim($_POST['from']);
// create regex to make sure name contains at least two letters
$namePattern = '/[a-z]{2,}/i';
if (!preg_match($namePattern,$_POST['from'])) {
  // if name fails the test, reset $valid flag and set $reason1
  $valid = false;
  $reason1 = 'Please enter a valid name.';
  }
// create regex to validate email address
$emailPattern = '/^\w[-.\w]*@([-a-z0-9]+\.)+[a-z]{2,4}$/i';
if (!preg_match($emailPattern,$_POST['email'])) {
  // if address fails the test, reset $valid flag and set $reason2
  $valid = false;
  $reason2 = 'The email address you submitted does not conform to
  the recognized standard for email addresses.';
  }

// if any test has failed, $valid will be false, so send failure msg
if (!$valid) {
  // if only one test has failed, either $reason1 or $reason2
  // will be an empty string, you can concatenate them
  // and only the right one will be output
  if (empty($reason1) xor empty($reason2)) {
    echo 'sent=failed&reason='.urlencode($reason1.$reason2);
	}
  // otherwise send both reasons separated by a new line character
  else {
    echo 'sent=failed&reason='.urlencode("$reason1\n$reason2");
	}
  }
else {

// initialize variables for To and Subject fields
################################################
# Replace 'david@example.com' with the address #
# you want the feedback to be sent to          #
################################################
$to = 'david@example.com';
$subject = 'Feedback from Flash site';

// build message body from variables received in the POST array
$message = 'From: '.$_POST['from']."\n\n";
$message .= 'Email: '.$_POST['email']."\n\n";
$message .= 'Address: '.$_POST['snail']."\n\n";
$message .= 'Phone: '.$_POST['phone']."\n\n";
$message .= 'Comments: '.$_POST['comments'];

// add additional email headers for more user-friendly reply
##################################################
# Replace 'Flash feedback<feedback@example.com>' #
# with an appropriate address for your website   #
##################################################
$additionalHeaders = "From: Flash feedback<feedback@example.com>\n";
$additionalHeaders .= "Reply-To: $_POST[email]";

// send email message
$OK = mail($to, $subject, $message, $additionalHeaders);
// let Flash know what the result was
if ($OK) {
  echo 'sent=OK';
  }
  else {
  echo 'sent=failed&reason='. urlencode('There seems to be a problem with the server. Please try later.');
  }
// curly brace added on next line to enclose original script in else clause
  }
?>