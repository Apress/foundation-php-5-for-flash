<?php
// assign data incoming from Flash to simpler variables

$a = $_POST['value1'];
$b = $_POST['value2'];
$type = $_POST['conversionType'];
$units1 = $_POST['units1'];
$units2 = $_POST['units2'];

// select the appropriate conversion formula
switch($type) {
  // Area conversion
  case 'acreToHa':
    $r = $a * .405;
    $unitsR = 'hectares';
    break;
  case 'haToAcre':
    $r = $a * 2.471;
    $unitsR = 'acres';
    break;
  case 'sqftToM2':
    $r = $a * .0929;
    $unitsR = 'm�';
    break;
  case 'sqydToM2':
    $r = $a * .836;
    $unitsR = 'm�';
    break;
  case 'M2toSqft':
    $r = $a / .0929;
    $unitsR = 'sq ft';
    break;
  case 'M2toSqyd':
    $r = $a / .836;
    $unitsR = 'sq yd';
    break;
  
  // Length conversion
  case 'inToCm':
    $r = $a * 2.54;
    $unitsR = 'cm';
    break;
  case 'cmToIn':
    $r = $a / 2.54;
    $unitsR = 'in';
    break;
  case 'ftToM':
    $r = $a * .305;
    $unitsR = 'm';
    break;
  case 'ydToM':
    $r = $a * .914;
    $unitsR = 'm';
    break;

  // Temperature conversion
  case 'cToF':
    $r = ($a / 5) * 9 + 32;
    $unitsR = '�F';
    break;
  case 'fToC':
    $r = ($a - 32) / 9 * 5;
    $unitsR = '�C';
    break;
  }

// format the result for transfer to Flash
switch($type) {
  default:
    // format first unit for singular and plural values 
    $output = plural($a, $units1).' = ';
	// format second unit, adjust temperatures to one decimal place
	$output .= strpos($unitsR, '�') === 0 ? sprintf('%0.1f', $r).$unitsR : plural(sprintf('%0.2f',$r), $unitsR);
    }
// send the data back to Flash
echo 'output='.urlencode($output);

// remove final "s" from measurement unit if number 1 or less
function plural($number, $unit) {
  // if 0 or 1, and unit ends in "s"
  if (abs($number) <= 1 && strrpos($unit, 's') == (strlen($unit) - 1)) {
    // concatenate and remove final "s"
    return $number.' '.substr_replace($unit, '', -1);
    }
  else { // concatenate without changing
    return $number.' '.$unit;
    }
  }
?>