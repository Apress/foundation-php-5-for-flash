<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Extracting substrings</title>
<style type="text/css">
body {font: 85% Arial, Helvetica, sans-serif;}
h1 {font-size: 150%; margin: 20px auto 15px 20px;}
p {width: 500px; margin: 10px 50px;}
ul {margin-left: 60px; width: 450px;}
#varName {width: 80px;}
#args {width: 120px;}
#myString {width: 250px;}
#answer {font-weight:bold; font-size:120%;margin: 20px 100px;}
</style>
</head>

<body>

<h1>Extracting substrings</h1>
<p>To extract part of a string, use substr(). The function takes two or three arguments:</p>
<ul>
  <li>The string you want to extract from</li>
  <li>The position of the first character to be extracted</li>
  <li>The length of the substring (if not specified, everything is extracted to the end of the string</li>
</ul>
<p>Use this form to experiment with substr(). Enter the variable name for a string in the first field, and the target string in the field alongside. Then enter the necessary arguments in the  bottom field, and click the Extract button.</p>
<form name="form1" id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  <p>Variable name: 
    <input name="varName" type="text" id="varName" value="<?php if (isset($_POST['varName'])) echo $_POST['varName']; ?>" />
     <strong>= ' 
     </strong>
     <input name="myString" type="text" id="myString" value="<?php if (isset($_POST['myString'])) echo $_POST['myString']; ?>" /> 
     <strong>';</strong></p>
  <p><strong>$extract = substr(</strong>    
    <input name="args" type="text" id="args" value="<?php if (isset($_POST['args'])) echo $_POST['args']; ?>" />
    <strong>);</strong></p>
  <p>
    <input type="submit" name="Submit" value="Extract" />
</p>
  <?php if ($_POST) {
    if (empty($_POST['myString'])) {
	  $errorList[] = 'You have not entered a target string';
	  }
	if (empty($_POST['varName'])) {
	  $errorList[] = 'You must supply a variable name for the string';
	  }
	if (empty($_POST['args'])) {
	  $errorList[] = 'You have not entered anything in the substr() field';
	  }
	else {
	  $args = explode(',', $_POST['args']);
	  if (count($args) <= 1 || count($args) > 3) {
	    $errorList[] = 'You must supply either two or three arguments, separated by commas';
	    }
	  if ($args[0] != $_POST['varName']) {
	    $errorList[] = 'The first argument must be identical to the variable the original string is assigned to';
	    }
	  }
	if (!empty($_POST['varName']) && $_POST['varName']{0} != '$') {
	  $errorList[] = 'Variable names in PHP must begin with $';
	  }
	if (!isset($errorList)) {
	  $result = '<p id="answer">$extract = ';
	  $myString = $_POST['myString'];
	  if (count($args) == 2) {
	    echo $result .= substr($myString,(int)trim($args[1]));
	    }
	  else {
	    echo $result .= substr($myString,(int)trim($args[1]),(int)trim($args[2]));
		}
	  $result .= '</p>';
	  }
	else {
	  $error = count($errorList) > 1 ? 'errors' : 'error';
	  echo "<p>The following $error occurred:</p><ul>";
	  foreach ($errorList as $item) {
	    echo "<li>$item</li>";
		}
	  echo '</ul>';
	  }
    }
?>
</form>
</body>
</html>