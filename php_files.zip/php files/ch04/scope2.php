<?php
function doubleIt() {
  // $myNum is declared as a global variable
  // so it has the same value as $myNum outside the function
  global $myNum;
  $myNum *= 2;
  }
// $myNum is 3
$myNum = 3;
echo 'Before: '.$myNum.'<br />';
// the function is called
doubleIt();
// because $myNum has global scope, the value is changed to 6
echo 'After: '.$myNum;
?>