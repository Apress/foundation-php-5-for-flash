<?php
function doubleIt() {
  $myNum *= 2;
  }
$myNum = 3;
echo 'Before: '.$myNum.'<br />';
doubleIt();
echo 'After: '.$myNum;
?>