<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Replacing substrings</title>
<style type="text/css">
body {font: 85% Arial,Helvetica,sans-serif;}
table {margin: 20px 30px;}
td { padding: 2px 5px 2px 10px; }
.hilite {background-color:#FFFF00;}
td.divider {background-color:#CCCCCC; padding: 5px;}
</style>
</head>

<body>
<table>
  <tr>
    <th scope="col">$original</th>
    <th scope="col">Arguments used </th>
    <th scope="col">$modified</th>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>substr_replace():</strong> replaces one portion of a string </td>
  </tr>
  <tr>
    <td><?php $original = 'Now is the time'; echo $original; ?> </td>
    <td>$modified = substr_replace($original, 'a good', 7, 3);</td>
    <td><?php echo $modified = substr_replace($original, 'a good', 7, 3); ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>$modified = substr_replace($original, 'not ', 7, 0);</td>
    <td><?php echo $modified = substr_replace($original, 'not ', 7, 0); ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>str_replace():</strong> replaces all instances in a string</td>
  </tr>
  <tr>
    <td><?php $original = 'I want money, money, money'; echo $original; ?></td>
    <td>$modified = str_replace('money','love',$original);</td>
    <td><?php echo $modified = str_replace('money','love',$original); ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>$modified = str_replace('m','h',$original);</td>
    <td><?php echo $modified = str_replace('m','h',$original); ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider">In PHP 5,    str_replace() takes a fourth argument, which records the number of replacements made </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>$modified = str_replace('m','h',$original,$count); </td>
    <td>$count has a value of <?php $modified = str_replace('m','h',$original,$count);
	echo $count; ?></td>
  </tr>
</table>
</body>
</html>
