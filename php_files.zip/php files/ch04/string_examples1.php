<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Finding the position of a character</title>
<style type="text/css">
body {font: 85% Arial,Helvetica,sans-serif;}
table {margin: 20px 30px;}
td { padding: 2px 20px; }
.hilite {background-color:#FFFF00;}
td.divider {background-color:#CCCCCC; padding: 5px;}
</style>
</head>

<body>
<table>
  <tr>
    <th><?php $myString = 'To be or not to be';
	     echo "\$myString = $myString"; ?></th>
    <th>Character(s) found</th>
    <th>Value of $pos</th>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>strpos(): </strong>case-sensitive search</td>
  </tr>
  <tr>
    <td>$pos = strpos($myString, 't');</td>
    <td><?php $pos = strpos($myString, 't');
	     // hilitePos() is a custom-built function that can be found at the bottom of the page
	     echo hilitePos($myString, $pos);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
  <tr>
    <td>$pos = strpos($myString, 'be');</td>
    <td><?php $pos = strpos($myString, 'be');
	    echo hilitePos($myString, $pos, 2);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>stripos():</strong> case-insensitive search</td>
  </tr>
  <tr>
    <td>$pos = stripos($myString, 't'); </td>
    <td><?php $pos = stripos($myString, 't');
	    echo hilitePos($myString, $pos);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>strrpos():</strong> case-sensitive search from end of string</td>
  </tr>
  <tr>
    <td>$pos = strrpos($myString, 'T');</td>
    <td><?php $pos = strrpos($myString, 'T');
	    echo hilitePos($myString, $pos);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>strripos(): </strong>case-insensitive search from end of string</td>
  </tr>
  <tr>
    <td>$pos = strripos($myString, 'T');</td>
    <td><?php $pos = strripos($myString, 'T');
	    echo hilitePos($myString, $pos);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
  <tr>
    <td colspan="3" class="divider"><strong>strrpos():</strong> case-sensitive search for a substring from end of string</td>
  </tr>
  <tr>
    <td>$pos = strrpos($myString, 'be');</td>
    <td><?php $pos = strrpos($myString, 'be');
	    echo hilitePos($myString, $pos, 2);
		 ?>
	</td>
    <td><?php echo $pos; ?></td>
  </tr>
</table>
</body>
</html>
<?php
// this uses PHP string functions to append a <span> tag to the first part of a string
// then it extracts the section to be highlighted and append a closing </span> tag
// finally, it extracts the rest of the string, and returns all three concatenated together
function hilitePos($string, $p, $len=1) {
  $start = substr_replace($string,'<span class="hilite">',$p);
  $middle = substr($string,$p,$len).'</span>';
  $end = substr($string,$p+$len);
  return $start.$middle.$end;
  }
?>