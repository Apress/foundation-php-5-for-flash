<?php
if (isset($_POST['action'])) {
  require_once('../classes/database.php');
  $db = new Database('localhost','flashuser','deepthought','bookstore');
  // this is common to all SQL queries
  $sql = 'SELECT books.book_id,title,publisher,isbn,description,
          list_price,store_price,image FROM books,publishers';
  // build rest of query based on action received from Flash
  switch($_POST['action']) {
    case 'getLatest':
	  $sql .=  ' WHERE books.pub_id = publishers.pub_id
			    ORDER BY book_id DESC LIMIT 5';
	  break;
	case 'fullList':
	  $sql .= ' WHERE books.pub_id = publishers.pub_id
			   ORDER BY title';
	  break;
	case 'byAuthor':
	  $sql .= ',authors,book_to_author
			   WHERE CONCAT(first_name," ",family_name)
			   LIKE "%'.trim($_POST['searchFor']).'%"
			   AND book_to_author.author_id = authors.author_id
			   AND book_to_author.book_id = books.book_id
			   AND books.pub_id = publishers.pub_id';
	  break;
	case 'byTitle':
	  $sql .= ' WHERE title LIKE "%'.trim($_POST['searchFor']).'%"
			   AND books.pub_id = publishers.pub_id';
	  break;
	case 'byISBN':
	  $isbn = str_replace('-','',$_POST['searchFor']);
	  $sql .= ' WHERE isbn = "'.trim($isbn).'"
			   AND books.pub_id = publishers.pub_id';
	}
  // run the query and process the result
  $result = $db->query($sql);
  $numRows = $result->num_rows;
  // begin the output string with number of results and action type
  $output = "total={$numRows}&resultType=".$_POST['action'];
  // create counter to identify related variables
  $i=0;
  while ($row = $result->fetch_assoc()) {
    foreach ($row as $key => $value) {
      // use the book_id to get a list of authors
      if ($key == 'book_id') {
        $output .= "&authors{$i}=".urlencode(getAuthors($db,$value));
        }
      // create a short version of the description
      elseif ($key == 'description') {
        $output .= "&short{$i}=".urlencode(shortDesc($value));
        }
      // create a variable made up of the array key and $i
      // and assign it the URL-encoded value
      $output .= "&{$key}{$i}=".urlencode($value);
      }
    // increment the counter for the variables to be sent to Flash
    $i++;
    }
  // send the results back to Flash
  echo $output;
  }

// get a list of authors using the book_id
function getAuthors($db,$book_id) {
  $authorQuery = "SELECT CONCAT(first_name,' ',family_name) AS author
                  FROM authors,book_to_author
			      WHERE book_to_author.book_id = $book_id
			      AND authors.author_id = book_to_author.author_id
			      ORDER BY family_name";
  $authorResult = $db->query($authorQuery);
  while ($row = $authorResult->fetch_assoc()) {
    // remove first 5 characters from any result beginning with "NULL"
    if (strpos($row['author'],'NULL') === 0) {
	  $authors[] = substr($row['author'],5);
	  }
	else {
      $authors[] = $row['author'];
	  }
	}
  if (!empty($authors)) {
    // if there are more than three authors, use the first two
	// and concatenate with "and others"
    if (count($authors) > 3) {
	  array_splice($authors,2);
	  return implode(', ',$authors).' and others';
	  }
	// otherwise create a comma-delimited string of authors
	else {
      return implode(', ',$authors);
	  }
	}
  else {
    return '';
	}
  }

// extract the first sentence from the description value
function shortDesc($description) {
  // find the position of the first period followed by a space
  $period = strpos($description, '. ');
  // find the first question mark or exclamation mark
  $marks = strcspn($description, '?!');
  // use the lesser value to extract the first sentence
  if ($period && $period < $marks) { 
    return substr($description,0,$period+1);
	}
  elseif ($period && $marks < $period) {
    return substr($description,0,$marks+1);
	}
  // if period has no value, return $description unchanged
  else {
    return $description;
	}
  }
?>