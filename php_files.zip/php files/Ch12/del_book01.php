<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete book confirmation</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form action="" method="post" name="deleteBooks" id="deleteBooks">
  <input name="confDel" type="submit" id="confDel" value="OK" />
  <input name="cancel" type="submit" id="cancel" value="Cancel" />
  <input name="book_id" type="hidden" id="book_id" value="" />
</form>
</body>
</html>
