<?php
require_once('admin_funcs.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Authors registered</title>
<link href="admin.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function checkDel(who,id) {
  var msg = 'Are you sure you want to delete '+who+'?';
  if (confirm(msg))
    location.replace('del_auth_pub.php?name='+who+'&author_id='+id);
  }
</script>
</head>
<body>
<?php insertMenu(); ?>
<div id="maincontent">
<h1>Authors registered in the database</h1>
<table>
  <tr class="hilite">
    <td>&nbsp;</td>
    <td><a href="edit_auth_pub.php">edit</a></td>
    <td><a href="javascript:checkDel()">delete</a></td>
  </tr>
</table>
</div>
</body>
</html>
