<?php 
require_once('admin_funcs.php');
require_once('../classes/database.php');
$db = new Database('localhost','flashadmin','fortytwo','bookstore',0);
// if OK button has been clicked, delete the books from the database
if ($_POST && array_key_exists('confDel',$_POST)) {
  $books = $_POST['book_id'];
  $titles = getTitles($db,$books);
  // multiple-table delete ** REQUIRES MySQL 4.0 OR HIGHER **
  $deleteBooks = "DELETE FROM books, book_to_author
                  USING books, book_to_author
                  WHERE books.book_id IN ($books)
                  AND book_to_author.book_id IN ($books)";
  $booksDeleted = $db->query($deleteBooks);
  }
// if Cancel button has been clicked, go to listbooks.php
elseif ($_POST && array_key_exists('cancel',$_POST)) {
  header('Location: listbooks.php');
  }
// if loaded from listbooks.php, get details of books to be deleted
elseif (isset($_GET['delete'])) {
  $books = $_GET['delete'];
  $titles = getTitles($db,$books);
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete book confirmation</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
insertMenu();
if (isset($booksDeleted)) {
  $alert = 'The following ';
  $alert .= $titles->num_rows > 1 ? 'titles were deleted:' : 'title was deleted:';
  }
elseif (isset($_GET) && isset($titles)) {
  $alert = 'Please confirm you want to delete the following:';
  }
echo "<p id='alert'>$alert</p><ul>";
while ($row = $titles->fetch_assoc()) {
  echo '<li>'.$row['title'].'</li>';
  }
?>
<form action="<?php $_SERVER['PHP_SELF'];?>" method="post" name="deleteBooks" id="deleteBooks">
  <input name="confDel" type="submit" id="confDel" value="OK" />
  <input name="cancel" type="submit" id="cancel" value="Cancel" />
  <input name="book_id" type="hidden" id="book_id" value="<?php echo $books;?>" />
</form>
</body>
</html>
