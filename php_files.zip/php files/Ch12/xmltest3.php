<?php
$xml = simplexml_load_file('books.xml');
foreach ($xml->Book as $book) {
  foreach($book->Authors->Author as $author) {
    foreach ($author->attributes() as $key => $value) {
      if ($key == 'country') {
        echo "$author lives in $value <br />";
	    }
	  }
    }
  }
?>