<?php
$xml = simplexml_load_file('books.xml');
foreach ($xml->Book as $book) {
  echo $book->Title.'<br />';
  foreach ($book->Authors->Author as $author) {
    echo $author.'<br />';
    }
  echo '<br />';
  }
?>