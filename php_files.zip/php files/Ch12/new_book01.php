<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Insert new book</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="maincontent">
<h1>Insert new book</h1>
<form name="bookDets" id="bookDets" method="post" action="">
  <table>
    <tr>
      <th class="leftLabel">Title:</th>
      <td><input name="title" type="text" class="widebox" id="title" value="" /></td>
    </tr>
    <tr>
      <th class="leftLabel">ISBN:</th>
      <td><input name="isbn" type="text" class="narrowbox" id="isbn" value="" /></td>
    </tr>
    <tr>
      <th class="leftLabel">Author(s):</th>
      <td><select name="author" size="6" multiple="multiple" id="author">
          <option value="choose" selected="selected">Select author(s)</option>
          <option value="other">Not listed</option>
        </select></td>
    </tr>
    <tr>
      <th class="leftLabel">Publisher:</th>
      <td><select name="publisher" id="publisher">
        <option value="0" selected="selected">Select publisher</option>
        <option value="other">Not listed</option>
      </select></td>
    </tr>
    <tr>
      <th class="leftLabel">Image:</th>
      <td>Yes
        <input name="image" type="radio" value="y" />
        No
        <input name="image" type="radio" value="n" /></td>
    </tr>
    <tr>
      <th class="leftLabel">Description:</th>
      <td><textarea name="description" id="description"></textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Insert new book" /></td>
    </tr>
  </table>
</form>
</div>
</body>
</html>
