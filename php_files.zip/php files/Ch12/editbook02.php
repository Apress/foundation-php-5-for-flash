<?php
require_once('admin_funcs.php');
require_once('../classes/database.php');
// this code always runs, and gets lists of authors and publishers
$db=new Database('localhost','flashuser','deepthought','bookstore',0);
$getAuthors = 'SELECT author_id,
               CONCAT(first_name," ", UPPER(family_name)) AS author
               FROM authors
               ORDER BY family_name, first_name';
$authors = $db->query($getAuthors);
$getPublishers = 'SELECT * FROM publishers ORDER BY publisher';
$publishers = $db->query($getPublishers);
// this block runs when the GET array has been set
// the book_id in the query string is used to get the book's details
if ($_GET && !$_POST) {
  $book_id = $_GET['book_id'];
  // get details of book from the books table
  $getDets = "SELECT title,isbn,pub_id,image,description
              FROM books WHERE book_id = $book_id";
  $bookDets = $db->query($getDets);
  // assign results to ordinary variables
  while ($row = $bookDets->fetch_assoc()) {
    $title = $row['title'];
    $isbn = $row['isbn'];
    $pub_id = $row['pub_id'];
    $image = $row['image'];
    $description = $row['description'];
    }
  // get list of authors from lookup table
  $getAuthors = "SELECT author_id FROM book_to_author
                 WHERE book_id = $book_id";
  $author_ids = $db->query($getAuthors);
  // filter results into an array of authors
  while ($row = $author_ids->fetch_assoc()) {
    $authorList[] = $row['author_id'];
    }
  }
// this block runs only if the form has been submitted
if ($_POST && array_key_exists('updateBook',$_POST)) {
  // check for empty fields
  foreach($_POST as $key=>$value) {
    // authors is a sub-array, so skip
    if (is_array($value)) continue;
    $value = trim($value);
    if (empty($value)) {
      if ($key == 'isbn') {
        $error[] = 'ISBN is required';
        }
      // if no publisher selected, value is 0, considered empty by PHP
      elseif ($key == 'publisher') {
        $error[] = 'You must select a publisher';
        }
      else {
        $error[] = ucfirst($key).' is required';
        }
      }
    }
  // remove any hyphens from ISBN and check for valid length
  $_POST['isbn'] = str_replace('-','',$_POST['isbn']);
  if (strlen($_POST['isbn']) != 10) {
    if (strlen($_POST['isbn']) != 13) {
      $error[] = 'ISBNs have 10 or 13 characters (excluding hyphens)';
      }
    }
  // check that an author has been chosen
  if ($_POST['author'][0] == 'choose' && count($_POST['author']) < 2) {
    $error[] = 'Select at least one author, or choose "Not listed"';
    }
  // if all fields correctly filled, prepare to insert in database
  if (!isset($error)) {
    // final preparations for insertion
	// escape quotes and apostrophes if magic_quotes_gpc off
    if (!get_magic_quotes_gpc()) {
      foreach($_POST as $key=>$value) {
        // skip author sub-array
        if (is_array($value)) continue;
        $temp = addslashes($value);
        $_POST[$key] = $temp;
        }
      }
    // create a Database instance, and set error reporting to plain text
    $db = new Database('localhost','flashadmin','fortytwo','bookstore',0);
    // first check that the same ISBN doesn't already exist
    $checkISBN = 'SELECT isbn FROM books
	              WHERE isbn = "'.$_POST['isbn'].'"';
    $result = $db->query($checkISBN);
    if ($result->num_rows > 0) {
      $error[] = 'A book with that ISBN already exists in the database';
      }
    else {
      // if ISBN unique, insert book in to books table
	  if ($_POST['publisher'] == 'other') $_POST['publisher'] = 0;
	  $insert = 'INSERT INTO books (title,isbn,pub_id,image,description)
                 VALUES ("'.$_POST['title'].'","'.$_POST['isbn'].'",'.
                 $_POST['publisher'].',"'.$_POST['image'].'",
                 "'.$_POST['description'].'")';
      $result = $db->query($insert);
      // get the primary key of the record just inserted
	  $getBook_id = 'SELECT book_id FROM books
                     WHERE isbn = "'.$_POST['isbn'].'"';
      $result = $db->query($getBook_id);
      $row = $result->fetch_assoc();
      $book_id = $row['book_id'];
	  // if "Select author(s)" still selected, remove it from the array
	  if ($_POST['author'][0] == 'choose') array_shift($_POST['author']);
      if (in_array('other',$_POST['author'])) {
	    $i = array_search('other', $_POST['author']);
		$_POST['author'][$i] = 0;
		}
      // build array of book_id and author_id pairs, one for each author
      $values = array();
      foreach ($_POST['author'] as $author_id) {
        $values[] = "($book_id, $author_id)";
        }
      // convert array to comma delimited string
      $values = implode(',',$values);
      // insert book_id/author_id pairs into lookup table
      $createLookup = 'INSERT INTO book_to_author (book_id, author_id)
                        VALUES '.$values;
      $result = $db->query($createLookup);
      // if successful, redirect to confirmation page
      if ($result) {
	    $db->close();
        header('Location: listbooks.php?action=inserted&title='.$_POST['title']);
        }
      }
	}
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Edit book</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php insertMenu(); ?>
<div id="maincontent">
<h1>Edit book</h1>
<?php
if (isset($error)) {
  echo '<div id="alert"><p>Please correct the following:</p><ul>';
  foreach ($error as $item) {
    echo "<li>$item</li>";
	}
  echo '</ul></div>';
  }
?>
<form name="bookDets" id="bookDets" method="post" action="">
  <table>
    <tr>
      <th class="leftLabel">Title:</th>
      <td><input name="title" type="text" class="widebox" id="title" value="<?php if (isset($_POST['title'])) echo $_POST['title']; 
	  elseif (isset($title)) echo $title; ?>" /></td>
    </tr>
    <tr>
      <th class="leftLabel">ISBN:</th>
      <td><input name="isbn" type="text" class="narrowbox" id="isbn" value="<?php if (isset($_POST['isbn'])) echo $_POST['isbn']; 
	  elseif (isset($isbn)) echo $isbn; ?>" /></td>
    </tr>
    <tr>
      <th class="leftLabel">Author(s):</th>
      <td><select name="author[]" size="6" multiple="multiple" id="author">
  <option value="choose" 
  <?php 
  if (isset($_POST['author']) && in_array('choose',$_POST['author'])) {
    echo 'selected="selected"'; } ?>
  >Select author(s)</option>
  <option value="other"
  <?php if (isset($authorList) && in_array(0,$authorList) || (isset($_POST['author']) && $_POST['author'] == 'other'))
    echo 'selected="selected"'; ?>
  >Not listed</option>
  <?php while ($row = $authors->fetch_assoc()) {
    echo '<option value="'.$row['author_id'].'"';
    if ((isset($authorList) && in_array($row['author_id'],$authorList)) || (isset($_POST['author']) && in_array($row['author_id'], $_POST['author']))) {
      echo 'selected="selected"';
      }
    echo '>'.$row['author'].'</option>';
    }
  ?>
  </select></td>
    </tr>
    <tr>
      <th class="leftLabel">Publisher:</th>
      <td><select name="publisher" id="publisher">
        <option value="0" 
		<?php if (isset($_POST['publisher']) && $_POST['publisher'] == '0')
		echo 'selected="selected"';?>>Select publisher</option>
        <option value="other"
        <?php
        if (isset($pub_id) && $pub_id == 0 || (isset($_POST['publisher']) && $_POST['publisher'] == 'other')) echo 'selected="selected"'; ?>
        >Not listed</option>
        <?php
        while ($row = $publishers->fetch_assoc()) {
          echo '<option value="'.$row['pub_id'].'"';
          if ((isset($pub_id) && $pub_id == $row['pub_id']) || (isset($_POST['publisher']) && $_POST['publisher'] == $row['pub_id']))
          echo 'selected="selected"';
        echo '>'.$row['publisher'].'</option>';
        }
      // close database connection
      $db->close();
      ?>
	  </select></td>
    </tr>
    <tr>
      <th class="leftLabel">Image:</th>
      <td>Yes
        <input name="image" type="radio" value="y"
        <?php if ((isset($image) && $image == 'y') || (isset($_POST['image']) && $_POST['image'] == 'y')) {
          echo 'checked="checked"'; }?>  /> 
        No 
        <input name="image" type="radio" value="n" 
        <?php if ((isset($image) && $image == 'n') || (isset($_POST['image']) && $_POST['image'] == 'n')) echo 'checked="checked"';?> /></td>
    </tr>
    <tr>
      <th class="leftLabel">Description:</th>
      <td><textarea name="description" id="description"><?php 
	  if (isset($_POST['description'])) echo $_POST['description']; 
	  elseif (isset($description)) echo $description; ?></textarea></td>
    </tr>
    <tr>
      <td><input name="book_id" type="hidden" id="book_id" value="
      <?php if ($_GET) echo $book_id;
         elseif (isset($_POST['book_id'])) echo $_POST['book_id'];?>" /></td>
      <td><input type="submit" name="updateBook" value="Update book details" /></td>
    </tr>
  </table>
</form>
</div>
</body>
</html>
