-- MySQL dump 10.9
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	4.1.9-nt


--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `author_id` int(10) unsigned NOT NULL auto_increment,
  `first_name` varchar(30) NOT NULL default '',
  `family_name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`author_id`)
) TYPE=MyISAM;

--
-- Dumping data for table `authors`
--


LOCK TABLES `authors` WRITE;
INSERT INTO `authors` VALUES (1,'David','Powers'),(2,'Sham','Bhangal'),(6,'Michael','Kofler'),(4,'Rachel','Andrew'),(5,'Allan','Kent'),(7,'Owen','Briggs'),(8,'Steven','Champeon'),(9,'Eric','Costello'),(10,'Matt','Patterson'),(11,'Kristian','Besley'),(12,'Craig','Grannell'),(13,'George','McLachlan'),(14,'Jason','Gilmore'),(15,'Kevin','Peaty'),(16,'Glenn','Kirkpatrick'),(17,'Nathan','Good'),(18,'David','Hirmes'),(19,'JD','Hooge'),(20,'Ken','Jokol'),(21,'Pavel','Kaluzhny'),(22,'Ty','Lettau'),(23,'NULL','Lifaros'),(24,'Jamie','MacDonald'),(25,'Gabriel','Mulzer'),(26,'Kip','Parker'),(27,'Keith','Peters'),(28,'Paul','Prudence'),(29,'Glen','Rhodes'),(30,'Manny','Tan'),(31,'Jared','Tarbell'),(32,'Brandon','Williams');
UNLOCK TABLES;

--
-- Table structure for table `book_to_author`
--

DROP TABLE IF EXISTS `book_to_author`;
CREATE TABLE `book_to_author` (
  `book_id` int(10) unsigned NOT NULL default '0',
  `author_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`book_id`,`author_id`)
) TYPE=MyISAM;

--
-- Dumping data for table `book_to_author`
--


LOCK TABLES `book_to_author` WRITE;
INSERT INTO `book_to_author` VALUES (6,6),(7,2),(7,11),(8,1),(8,12),(8,13),(9,7),(9,8),(9,9),(9,10),(10,2),(11,14),(12,1),(12,4),(12,5),(13,15),(13,16),(14,18),(14,19),(14,20),(14,21),(14,22),(14,23),(14,24),(14,25),(14,26),(14,27),(14,28),(14,29),(14,30),(14,31),(14,32),(15,17),(16,12),(17,1);
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `book_id` int(10) unsigned NOT NULL auto_increment,
  `pub_id` int(10) unsigned NOT NULL default '0',
  `isbn` varchar(13) NOT NULL default '',
  `title` varchar(150) NOT NULL default '',
  `image` enum('y','n') NOT NULL default 'y',
  `description` text NOT NULL,
  `list_price` varchar(10) default NULL,
  `store_price` varchar(10) default NULL,
  PRIMARY KEY  (`book_id`)
) TYPE=MyISAM;

--
-- Dumping data for table `books`
--


LOCK TABLES `books` WRITE;
INSERT INTO `books` VALUES (6,2,'1590591445','The Definitive Guide to MySQL, 2nd Edition','y','This second edition of Michael Kofler\'s acclaimed MySQL book has updated and expanded to cover MySQL 4.0, the most recent production release of the popular open source database, which boasts more than 4 million users worldwide.\r\nLike the first edition, this revision, which has been renamed to reflect the breadth and depth of Kofler\'s coverage of the topic, provides a thorough introduction to the installation, configuration, implementation, and administration of MySQL. In addition, Kofler demonstrates how you can use MySQL in conjunction with various other technologies to create database-driven websites, and he gives practical advice on database design. Kofler also covers what\'s coming up next in MySQL 4.1.\r\nThe Definitive Guide to MySQL, Second Edition is an irreplaceable resource for MySQL novices and experts alike.','$49.99','$32.99'),(7,1,'1590593030','Foundation Flash MX 2004','n','If you\'ve never used Flash before and you\'re looking for a book that will give you a rock solid grounding in Flash MX 2004, then this is the title for you. This book uses a series of structured exercises to give you the broad, solid foundation knowledge you need to start your exploration of Flash from scratch. Foundation Flash MX 2004 uses a proven sequential, detailed, and accessible tutorial style to ensure that you\'ll retain your learning and be able to draw on it throughout your Flash career.\r\nMacromedia Flash MX 2004 is an exciting product, providing rich creative opportunities for Flash designers and developers at all levels of ability and experience. No single book can hope to provide adequate coverage of all aspects of Flash MX 2004, which is why this book focuses relentlessly on the core skills that you need to get you started: understanding the interface; familiarizing yourself with the creative tools and their capabilities; grasping the relationships between the different components that make up a Flash movie; getting insight into how to put all the pieces together and hook them up with ActionScript. All these aspects (and much more) are covered in detailed tutorials and exercises, reinforced with a case study that runs throughout the book to apply everything in a real-world context.\r\nCovers both Flash MX 2004 and Flash MX Professional 2004!','$29.99','$19.79'),(8,1,'1590593081','Foundation Dreamweaver MX 2004','y','Dreamweaver MX 2004 is the latest version of Macromedia\'s world-class visual web-authoring tool, which includes powerful yet easy-to-use database integration. Unlike many other books, Foundation Dreamweaver MX 2004 focuses on both sides of coin � no matter what your background, this book will give you a solid foundation in graphic design and layout issues as well as full training in the powerful server-side and database integration features that Dreamweaver offers. The truth is that in today\'s climate database integration is no more of an extra than faultless visual design, and this book is here to guide you through this new world, covering dynamic scripting with PHP and the popular MySQL database.\r\nEven if you are already using Dreamweaver and want to extend your skills towards dynamic content, interactive and engaging to your visitors. Or maybe you�re a developer who wants to make the most of this sophisticated productivity tool and take full advantage of the renowned Dreamweaver interface to improve your workflow. Foundation Dreamweaver MX 2004 gives you the essential grounding that you�ll need in the all-important design context. Whether a complete novice or a past user, after reading this book, you\'ll be fluent in the full breadth of the powerful functionality that Dreamweaver MX 2004 has to offer. This book presents a unique learning curve backed up by solid real-world case studies and tutorials.','$34.99','$24.49'),(9,1,'159059231X','Cascading Style Sheets: Separating Content from Presentation','y','CSS is one of the trio of core client-side web professional skills: HTML for markup, JavaScript for dynamism, and CSS for style. All web professionals who want to take their page design to the next level, with all the advantages that CSS brings, will need this book.\r\nThis book is a focused guide to using Cascading Style Sheets (CSS) for the visual design of web pages. It provides concise coverage of all the essential CSS concepts developers need to learn (such as separating content from presentation, block and inline elements, inheritance and cascade, the box model, typography, etc). It also covers the syntax needed to effectively use CSS with your markup document (for example CSS rules, how to structure a style sheet, linking style sheets to your (X)HTML documents, CSS boxes etc).\r\nCSS (Cascading Style Sheets) is a powerful technology that can be used to add style and structure to your web pages without needing to resort to \"hacks\" such as HTML table layouts and \"spacer images\". However, this is not the only advantage over other styling methods. You can specify your CSS styles in a separate file, then apply those styles to every page in your web site. When you want to change a style on your site, you can do it by modifying one style sheet, rather having to update every page. This is only one example of the many advantages CSS brings to your web development work.','$39.99','$27.19'),(10,1,'1590593057','Foundation ActionScript for Flash MX 2004','y','Flash guru Sham Bhangal brings us the third edition of everybody\'s favorite beginner level Flash scripting book: Foundation ActionScript. With the release of Flash MX 2004, scripting in Flash has moved from being a desirable asset to an essential skill in the world of web design and development. ActionScript is, quite simply, the key to real power in Flash. Flash is now both a design tool and a development tool, and ActionScript can easily scare designers.\r\nThis book is for anyone who has ever looked in awe at a cutting-edge Flash site, then taken a look at some code, and run in the other direction. Learning ActionScript with friends of ED will not turn you into a boring programmer, it will turn you into someone who finally has the power to achieve what they want with their web design, and can liberate their creative urges.\r\nThis book will take you from knowing nothing about ActionScript to a firm knowledge that will allow you to exercise a previously unimaginable amount of power over your Flash movies. It does this with fully worked examples throughout, and a case study that will leave you with a cutting-edge Flash site by the end of the book.','$34.99','$24.49'),(11,2,'1893115518','Beginning PHP 5 and MySQL: From Novice to Professional','n','This comprehensive book introduces two of the most popular web application building technologies on the planet: PHP scripting language and MySQL database server. This book not only explains the core aspects of each technology, but also provides valuable instruction for using them simultaneously to create dynamic, data-driven web applications.\r\nThis is an ideal read for the web designer, programmer, hobbyist, or novice who wants to learn how to create applications with PHP 5 and MySQL 4.','$39.99','$26.39'),(12,2,'1590593502','PHP Web Development with Dreamweaver MX 2004','y','PHP is the most popular Open source server-side scripting language, with extensive support available in Dreamweaver MX. This concise, no-nonsense book teaches you how to develop accessible, standards-compliant PHP-driven websites using PHP 4 and Macromedia Dreamweaver MX 2004.\r\nPHP Web Development with Macromedia Dreamweaver MX 2004 presents real-world tutorials so you can expect fast results as you progress through the book. It also covers vital web development topics such as web standards principles and implementation, and it includes a useful setup section to get you up-and-running quickly and easily.','$39.99','$27.19'),(13,1,'1590592077','Flash Cartoon Animation: Learn from the Pros','n','You want to make an animated film. You\'ve got the idea. You\'ve got Macromedia Flash. But where do you start?\r\nWhat\'s the best way to script your cartoon, how do you start animating with Flash, what do you really need to know in order to get your ideas out there to make you famous?\r\nWho better to ask than two seasoned professionals, who\'ve not only worked for Disney, but also run the hugely successful cult website - funnyazhell.','$29.99','$19.79'),(14,1,'1590594290','Flash Math Creativity, 2nd Edition','y','The seminal book, Flash Math Creativity, completely revised for Flash MX 2004 and AS 2.0!\r\nMacromedia Flash is the industry standard design tool for digital design and web programming. With the release of the latest version of this exciting product, Flash MX 2004 and its accompanying built-in language ActionScript 2.0, Macromedia has yet again upped the standard for creating immersive digital experiences.\r\nThis book revolves around Flash and math. It\'s what you do in your spare time: just take little ideas and mess around with them. This is a book of inspiration, beautiful enough to leave on the coffee table, but addictive enough to keep by your computer and sneak out while no-one\'s looking so you can go back to that movie that you were tinkering with \'til 3 o\'clock this morning. It\'s a fun book!','$49.99','$32.99'),(15,2,'159059441X','Regular Expression Recipes: A Problem-Solution Approach','n','Regular Expressions are an essential part of programming, but they sure are hard to come to grips with, aren\'t they? Fortunately, we have the answer for you! Regular Expression Recipes provides you with all the open source regular expressions you\'ll ever need, and explains how to use each one. This way, you can learn by example, rather than muddling through countless pages of explanatory syntax.\r\nAuthor Nathan A. Good includes syntax references only when necessary. Languages covered include Perl, PHP, grep, vim, Python, and shell. Web and applications developers, and system administrators will find the examples both accurate and relevant. And this book acts as a useful reference to keep handy for those moments when an answer is needed fast.','$34.99','$23.79'),(16,1,'1590594304','Web Designer\'s Reference','n','Most web design books concentrate on a single technology or piece of software, leaving the designer to figure out how to put all the pieces together. This book is different. Web Designer\'s Reference provides a truly integrated approach to web design. Each of the dozen chapters covers a specific aspect of creating a web page, such as working with typography, adding images, creating navigation, and crafting CSS layouts. In each case, relevant XHTML elements are explored along with associated CSS, and visual design ideas are discussed. Several practical examples are provided, which you can use to further your understanding of each subject. This highly modular and integrated approach means that you learn about technologies in context, at the appropriate time and, upon working through each chapter, you craft a number of web page elements that you can use on countless sites in the future.\r\nThis book is ideal for those making their first moves into standards-based web design, experienced designers who want to learn about modern design techniques and move toward creating CSS layouts, graphic designers who want to discover how to lay out their designs, and veteran web designers who want a concise reference guide.','$34.99','$23.09'),(17,1,'1590594665','Foundation PHP 5 for Flash','y','Want to create rich, interactive web content with Flash, but don\'t have the know-how? <b>Foundation PHP 5 for Flash</b> shows you how to put the power of two of the most popular web technologies - PHP and the MySQL database system - behind your Flash movies. It covers the latest versions of PHP, MySQL,and ActionScript,  raising your skills to new levels, and keeping you ahead of the field.\r\nThe book is aimed at Flash developers who are familiar with the Flash development environment, but have no experience of server-side programming or database management. Starting from first principles, it teaches you the core syntax of PHP and SQL, and the fundamentals of relational database design. It\'s written as a combination of reference and tutorial, not only giving you hands-on experience of practical applications, but also serving as a book that you\'ll want to refer to again and again.\r\nCovers PHP 5.0, MySQL 4.1, and ActionScript 2.0.','$44.99','$29.70');
UNLOCK TABLES;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
CREATE TABLE `publishers` (
  `pub_id` int(10) unsigned NOT NULL auto_increment,
  `publisher` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`pub_id`)
) TYPE=MyISAM;

--
-- Dumping data for table `publishers`
--


LOCK TABLES `publishers` WRITE;
INSERT INTO `publishers` VALUES (1,'friends of ED'),(2,'Apress');
UNLOCK TABLES;


