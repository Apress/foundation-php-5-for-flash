<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>List books</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="maincontent">
  <form name="list" id="list" method="post" action="">
    <table id="booklist">
      <tr>
        <th scope="col">Title</th>
        <th scope="col">Authors</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
      <tr>
        <td colspan="4">No books listed </td>
      </tr>
      <tr class="hilite">
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td class="ctr"><input name="book_id[]" type="radio" value="" /></td>
        <td class="ctr"><input name="delete[]" type="checkbox" value="" /></td>
      </tr>
      <tr>
        <td colspan="2"><a href="">Prev</a></td>
        <td colspan="2"><a href="">Next</a></td>
      </tr>
      <tr>
        <td colspan="4"><input name="editBook" type="submit" id="editBook" value="Edit book" />
          <input name="delBook" type="submit" id="delBook" value="Delete book(s)" /></td>
      </tr>
    </table>
  </form>
</div>
</body>
</html>
