<?php
require_once('admin_funcs.php');
require_once('../classes/database.php');
$db = new Database('localhost','flashadmin','fortytwo','bookstore',0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Get book prices</title>
<link href="admin.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php insertMenu(); ?>
<div id="maincontent">
  <table>
    <tr>
      <th scope="col">Title</th>
      <th scope="col">List price</th>
      <th scope="col">Store price</th>
    </tr>
<?php
if (!file_exists('bookprices.xml')) {
  echo '<tr><td colspan="3">Can\'t find XML feed</td></tr>';
  }
else {
  // load XML file as a SimpleXML object
  $xml = simplexml_load_file('bookprices.xml');
  // loop through each Book element to extract ListPrice, OurPrice and
  // ISBN, and use the details to update the books table
  foreach ($xml->Book as $book) {
    $updatePrices = "UPDATE books SET list_price ='$book->ListPrice',
                     store_price = '$book->OurPrice'
                     WHERE isbn = '$book->ISBN'";
    $db->query($updatePrices);
    // get the price information from the books table
    $confirmUpdate = "SELECT title, list_price, store_price
                      FROM books WHERE isbn = '$book->ISBN'";
    $result = $db->query($confirmUpdate);
    // if that ISBN exists in the database, display the result
    if ($result->num_rows) {
      $row = $result->fetch_assoc();
      echo '<tr><td>'.$row['title'].'</td><td>'.$row['list_price'].'</td>';
      echo '<td>'.$row['store_price'].'</td></tr>';
      }
    }
  }
?>
  </table>
</div>
</body>
</html>
