<?php
$db = new SQLiteDatabase('3esl.db');
$row = $db->query("SELECT * FROM wordlist LIMIT 10");
//while ($data = $row->fetch()) {
foreach ($row as $data) {
  echo $data['word'].'<br />';
  }
unset($db);
?>