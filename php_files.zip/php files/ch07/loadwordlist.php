<?php
// create database file and table structure
$db = new SQLiteDatabase('../data/3esl.db');
$createTable = 'CREATE TABLE wordlist (word VARCHAR(30))';
$db->query($createTable);

// initialize array for words and open text file
$words = array();
$fh = fopen('3esl.txt', 'r');
while (!feof($fh)) {
  // remove any white space and new line characters from each line
  $word = trim(fgets($fh));
  // eliminate words with periods or less than three characters long
  if (!strpos($word, '.') && strlen($word) > 2) {
    // escape any quotes
    $words[] = sqlite_escape_string($word);
    }
  }
// close text file
fclose($fh); 

// create SQL to insert words in a single transaction
$sql = 'BEGIN;';
foreach ($words as $word) {
  $sql .= "INSERT INTO wordlist VALUES ('$word');";
  }
$sql .= 'COMMIT;';

// perform transaction and close database 
$db->query($sql);
unset($db);
echo 'Done';
?>