<?php
require_once('../classes/database.php');
// initialize connection variables
$hostname = 'localhost';
$username = 'flashuser';
$password = 'deepthought';

// create new instance of mysqli class and connect to database
$db = new Database($hostname, $username, $password, 'phpflash', 0);

// create SQL, query database, and store result in $result object
$sql = 'SELECT * FROM wordlist';
$result = $db->query($sql);

// use num_rows property to display total number of records
$total = $result->num_rows;
echo "<h1>Total words: $total</h1>";

// loop through $result object one row at a time and display contents
while ($row = $result->fetch_assoc()) {
  echo $row['word'].'<br />';
  }

// close database link
$db->close();
?>