<?php
require_once('../classes/database.php');
// initialize connection variables
$hostname = 'localhost';
$username = 'flashuser';
$password = 'deepthought';

// create new instance of mysqli class and connect to database
$db = new Database($hostname, $username, $password, 'phpflash');

// set limits for words to be retrieved
$numWords = 250;
$min = 5;

// create SQL, query database, and store result in $result object
$sql = "SELECT word FROM wordlist
        WHERE LENGTH(word) >= $min
		ORDER BY RAND()
		LIMIT $numWords";
$result = $db->query($sql);

// initialize results string, counter and regular expression
$words = '';
$count = 0;
$pattern = "/$'|[A-Z\.]/";

// loop through results, but skip any that match the regex
while ($row = $result->fetch_assoc()) {
  if (preg_match($pattern, $row['word']))
    continue;
  // use counter to create unique variable (word0, etc) and build
  // string of name/value pairs to transmit to Flash  
  $words .= '&word'.$count.'='.urlencode($row['word']);
  $count++;
  }

// output string to send data to Flash
// begin with total number of words accepted, then string of name/value pairs
echo 'total='.$count.$words;

// close database link
$db->close();
?>