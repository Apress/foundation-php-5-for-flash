<?php
$hostname = 'localhost';
$username = 'flashuser';
$password = 'deepthought';

$db = new mysqli($hostname, $username, $password, 'phpflash');

$sql = 'SELECT * FROM wordlist';
$result = $db->query($sql);

$total = $result->num_rows;
echo "<h1>Total words: $total</h1>";
while ($row = $result->fetch_assoc()) {
  echo $row['word'].'<br />';
  }
?>