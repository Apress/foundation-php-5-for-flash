<?php
// create instance of SQLiteDatabase
$db = new SQLiteDatabase('../data/3esl.db');

// initialize database query
$numWords = 250;
$min = 5;
$sql = "SELECT word FROM wordlist WHERE LENGTH(word) >= $min ORDER BY RANDOM(*) LIMIT $numWords";

// execute query
$result = $db->query($sql);

// initialize results string, counter and regular expression
$words = '';
$count = 0;
$pattern = "/$'|[A-Z\.]/";

// loop through results, but skip any that match the regex
foreach ($result as $row) {
  if (preg_match($pattern, $row['word']))
    continue;
  // use counter to create unique variable (word0, etc) and build
  // string of name/value pairs to transmit to Flash  
  $words .= '&word'.$count.'='.urlencode($row['word']);
  $count++;
  }
unset($db);

// output string to send data to Flash
// begin with total number of words accepted, then string of name/value pairs
echo 'total='.$count.$words;
?>