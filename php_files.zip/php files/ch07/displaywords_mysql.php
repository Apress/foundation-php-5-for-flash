<?php
$hostname = 'localhost';
$username = 'flashuser';
$password = 'deepthought';

$link = mysql_pconnect($hostname, $username, $password);
mysql_select_db('phpflash', $link);

$query = 'SELECT * FROM wordlist';
$result = mysql_query($query, $link);

$total = mysql_num_rows($result);
echo "<h1>Total words: $total</h1>";
while ($row = mysql_fetch_assoc($result)) {
  echo $row['word'].'<br />';
  }
?>