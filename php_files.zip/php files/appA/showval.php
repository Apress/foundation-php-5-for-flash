<?php
function showVal($variable, $varDesc='') {
  if ($_GET && $_GET['debug']) {
  $varDesc = !empty($varDesc) ? " of $varDesc" : $varDesc;
  if (is_array($variable) && count($variable) > 0) {
    echo '<p>Contents'.$varDesc.' - array with elements:<br />';
	foreach ($variable as $key => $value) {
	  echo $key.' => '.$value.'<br />';
	  }
	echo '</p>';
  }
  elseif (is_array($variable) && count($variable) == 0) {
    echo '<p>Contents'.$varDesc.': empty array</p>';
    }
  else {
    echo '<p>Contents'.$varDesc.": $variable</p>";
	}
  }
}
?>