<?php
$db = mysql_connect('localhost','username','password');
$result = mysql_query('SELECT VERSION()');
$row = mysql_fetch_row($result);
echo "<p>MySQL version is: $row[0]</p>";
echo '<p>PHP version is: '.phpversion().'</p>';
?>