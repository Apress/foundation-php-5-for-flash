<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Changing array values</title>
</head>

<body>
<?php
$titles = array('PHP 5 for Flash', 'ActionScript for Flash MX 2004');
echo '<pre>';
echo '<h2>Using a foreach loop</h2>';
foreach ($titles as $title) {
  $title = 'Foundation '.$title;
  echo $title.'<br />';
  }
print_r($titles);
echo '<h2>Using a for loop</h2>';
for ($i = 0; $i < count($titles); $i++) {
  $titles[$i] = 'Foundation '.$titles[$i];
  echo $titles[$i].'<br />';
  }
print_r($titles);
echo '</pre>';
?>
</body>
</html>
