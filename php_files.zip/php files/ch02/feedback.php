<?php
// initialize variables for To and Subject fields
################################################
# Replace 'david@example.com' with the address #
# you want the feedback to be sent to          #
################################################
$to = 'david@example.com';
$subject = 'Feedback from Flash site';

// build message body from variables received in the POST array
$message = 'From: '.$_POST['from']."\n\n";
$message .= 'Email: '.$_POST['email']."\n\n";
$message .= 'Address: '.$_POST['snail']."\n\n";
$message .= 'Phone: '.$_POST['phone']."\n\n";
$message .= 'Comments: '.$_POST['comments'];

// add additional email headers for more user-friendly reply
##################################################
# Replace 'Flash feedback<feedback@example.com>' #
# with an appropriate address for your website   #
##################################################
$additionalHeaders = "From: Flash feedback<feedback@example.com>\n";
$additionalHeaders .= "Reply-To: $_POST[email]";

// send email message
$OK = mail($to, $subject, $message, $additionalHeaders);
// let Flash know what the result was
if ($OK) {
  echo 'sent=OK';
  }
  else {
  echo 'sent=failed&reason='. urlencode('There seems to be a problem with the server. Please try later.');
  }
?>
