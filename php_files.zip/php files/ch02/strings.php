<?php
echo 'green bottles 10' - '1';
?>