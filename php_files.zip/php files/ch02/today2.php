<?php
echo 'theDate='.urlencode(date('l, F jS, Y'));
?>