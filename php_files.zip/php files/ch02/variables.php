<?php
$myVar = '12';
$type = gettype($myVar);
echo "Value: $myVar Type: $type ";
?>