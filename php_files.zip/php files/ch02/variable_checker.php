<?php
foreach ($_POST as $key=>$value) {
  $received .= "$key = $value\r\n";
  }

$printout = fopen("variables.txt", "w");
fwrite($printout, $received);
fclose($printout);
?>