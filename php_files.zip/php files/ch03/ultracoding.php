<?php
$var = 5;
$size = $var > 20 ? 'big' : ($var > 10 ? 'medium' :'small');
echo $size;
?>