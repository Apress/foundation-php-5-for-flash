<?php
$value = 6;
$unit1 = ' kg';
$unit2 = ' lb ';
$pounds = $value / .454;
echo $value.$unit1.' equals '.$pounds.$unit2;
?>