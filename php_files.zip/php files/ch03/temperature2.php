<?php
$value = 37;
$conversionType = 'cToF'; // Celsius to Fahrenheit
if ($conversionType == 'cToF') {
  $result = $value / 5 * 9 + 32;
  $resultUnit = ' degrees F';
  }
else {
  $result = ($value - 32) / 9 * 5;
  $resultUnit = ' degrees C';
  }
echo $result.$resultUnit;
?>