<?php
$c = 37;
$f = 98.6;
$cToF = $c / 5 * 9 + 32;
echo $cToF.' fahrenheit<br />';
$fToC = $f - 32 / 9 * 5;
echo $fToC.' celsius';
?>