<?php
$value = 37;
$conversionType = 'cToF'; // Celsius to Fahrenheit
// uncomment the next line to convert Fahrenheit to Celsius
$conversionType = 'fToC'; // Fahrenheit to Celsius
switch($conversionType) {
  case 'cToF':
    $result = $value / 5 * 9 + 32;
    $resultUnit = ' degrees F';
    break;
  case 'fToC':
    $result = ($value - 32) / 9 * 5;
    $resultUnit = ' degrees C';
    break;
  }
echo $result.$resultUnit;
?>