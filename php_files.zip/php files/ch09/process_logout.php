<?php
// verify correct variable received in POST array
if (isset($_POST['logmeout'])) {
  session_start();
  unset($_SESSION['authenticated']);
  session_destroy();
  echo 'status=goodbye';
  }
?>