<?php session_start();
if (!isset($_SESSION['authenticated'])) {
  header('Location: http://localhost/phpflash/ch09/login.html');
  exit();
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Register new user</title>
</head>
<body bgcolor="#ffffff">
<!--url's used in the movie-->
<!--text used in the movie-->
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="550" height="400" id="register_protected" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="register_protected.swf" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="register_protected.swf" quality="high" bgcolor="#ffffff" width="550" height="400" name="register_protected" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
</body>
</html>