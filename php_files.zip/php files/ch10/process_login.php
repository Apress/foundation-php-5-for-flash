<?php
// check correct variables have been received through the POST array
if (isset($_POST['username']) && isset($_POST['pwd'])) {

  // initiate the session
  session_start();
  // include the Database classes
  require_once('../classes/database_mysqli.php');

  // escape quotes and apostrophes if magic_quotes_gpc off
  foreach($_POST as $key=>$value) {
    if (!get_magic_quotes_gpc()) {
      $temp = addslashes($value);
	  $_POST[$key] = $temp;
	  }
    }

  // create a Database instance and check username and password
  $db = new Database('localhost','flashuser','deepthought','phpflash');
  $sql = 'SELECT * FROM users WHERE username = "'.$_POST['username'].'"
          AND pwd = "'.sha1($_POST['pwd']).'"';
  $result = $db->query($sql);

  // if a match is found, approve entry; otherwise reject
  if ($result->num_rows > 0) {
    $_SESSION['authenticated'] = $_POST['username'];
    echo 'authenticated=ok';
    }
  else {
    echo 'authenticated=getLost';
    }

  // close the database connection  
  $db->close();
  }
?>