<?php
// set sort order for results
$order = ' ORDER BY family_name, first_name, username';

// include the Database classes
require_once('../classes/database.php');

// escape quotes and apostrophes if magic_quotes_gpc off
foreach($_POST as $key=>$value) {
  if (!get_magic_quotes_gpc()) {
    $temp = addslashes($value);
    $_POST[$key] = $temp;
    }
  }

// Register new user if "action" is set to "register" in POST array
if ($_POST['action'] == 'register') {
  // check whether anyone already has the same username
  $unique = checkDuplicate($_POST['username']);
  if ($unique) {
    $db = new Database('localhost','flashadmin','fortytwo','phpflash');
    $sql = 'INSERT INTO users (first_name,family_name,username,pwd)
       VALUES ("'.$_POST['first_name'].'","'.$_POST['family_name'].'",
       "'.$_POST['username'].'","'.sha1($_POST['pwd']).'")';
    $result = $db->query($sql);
    if ($result) {
      $created = 'Account created for '.$_POST['first_name'].' '.$_POST['family_name'];
      echo 'duplicate=n&message='.urlencode($created);
      }
    }
  }
elseif ($_POST['action'] == 'listAll') {
  // code for retrieving full list
  $sql = 'SELECT * FROM users'.$order;
  echo getUserList($sql);
  }
elseif ($_POST['action'] == 'find') {
  // code for search by name, etc
  // remove any leading or trailing blank spaces from input
  $input['first_name'] = trim($_POST['first_name']);
  $input['family_name'] = trim($_POST['family_name']);
  $input['username'] = trim($_POST['username']);
  // create an array of search parameters for use in SQL query
  $searchParams = array();
  $i = 0;
  foreach ($input as $key => $value) {
    if (strlen($value) > 0) {
      $searchParams[$i] = $key.' LIKE "%'.$value.'%"';
      $i++;
      }
    }
  // create SQL query and concatenate with parameters and sort order
  $sql = 'SELECT * FROM users WHERE '.join($searchParams,' AND ').$order;
  // query database and send results back
  echo getUserList($sql);
  }
elseif ($_POST['action'] == 'getDetails') {
  // get user details for updating
  $sql = 'SELECT * FROM users WHERE user_id = '.$_POST['user_id'];
  echo getDetails($sql);
  }
elseif ($_POST['action'] == 'doUpdate') {
  // update record
  $unique = checkDuplicate($_POST['username'], $_POST['user_id']);
  if ($unique) {
    $db = new Database('localhost','flashadmin','fortytwo','phpflash');
    $sql = 'UPDATE users SET first_name = "'.$_POST['first_name'].'",
           family_name = "'.$_POST['family_name'].'",
           username = "'.$_POST['username'].'"';
    if ($_POST['pwdChange'] == 'newPwd') {
      $sql .= ', pwd = "'.sha1($_POST['pwd']).'"';
    }
    $sql .= ' WHERE user_id = '.$_POST['user_id'];
    $db->query($sql);
    $db->close();
    $updated = 'Account updated for '.$_POST['first_name'].' '.$_POST['family_name'];
    $output = 'duplicate=n&message='.urlencode($updated);
    // display revised list
    $revisedList = 'SELECT * FROM users'.$order;
	echo $output .= '&'.getUserList($revisedList);
    }
  }
elseif ($_POST['action'] == 'doDelete') {
  // delete record
  }
elseif ($_POST['action'] == 'logout') {
  // logout code goes here
  }

// Check for duplicate use of username
function checkDuplicate($username, $user_id = 0) {
  $db = new Database('localhost','flashuser','deepthought','phpflash');
  $sql = "SELECT username FROM users WHERE username = '$username'";
  // add to SQL if user_id supplied as argument
  if ($user_id > 0) {
    $sql .= " AND user_id != $user_id";
    }
  $result = $db->query($sql);
  $numrows = $result->num_rows;
  $db->close();
  
  // if username already in use, send back error message
  if ($numrows > 0) {
    $duplicate = 'Duplicate username. Please choose another.';
    echo 'duplicate=y&message='.urlencode($duplicate);
    exit();
    }
  else {
    return true;
    }
  }
// gets a list of users
function getUserList($sql) {
  $db = new Database('localhost','flashuser','deepthought','phpflash');
  $result = $db->query($sql);
  $numrows = $result->num_rows;
  $userlist = "total=$numrows";
  $counter = 0;
  while ($row = $result->fetch_assoc()) {
    $userlist .= '&user_id'.$counter.'='.$row['user_id'];
    $userlist .= '&first_name'.$counter.'='.urlencode(stripslashes($row['first_name']));
    $userlist .= '&family_name'.$counter.'='.urlencode(stripslashes($row['family_name']));
    $userlist .= '&username'.$counter.'='.urlencode($row['username']);
    $counter++;
    }
  $db->close();
  return $userlist;
  }
// gets details for an individual record
function getDetails($sql) {
  $db = new Database('localhost','flashuser','deepthought','phpflash');
  $result = $db->query($sql);
  while ($row = $result->fetch_assoc()) {
    $details = 'user_id='.$row['user_id'];
    $details .= '&first_name='.stripslashes(urlencode($row['first_name']));
    $details .= '&family_name='.stripslashes(urlencode($row['family_name']));
    $details .= '&username='.urlencode($row['username']);
    $details .= '&pwd='.$row['pwd'];
    }
  $db->close();
  return $details;
  }
?>