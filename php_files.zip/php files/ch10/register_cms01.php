<?php
// include the Database classes
require_once('../classes/database.php');

// escape quotes and apostrophes if magic_quotes_gpc off
foreach($_POST as $key=>$value) {
  if (!get_magic_quotes_gpc()) {
    $temp = addslashes($value);
    $_POST[$key] = $temp;
    }
  }

// Register new user if "action" is set to "register" in POST array
if ($_POST['action'] == 'register') {
  // check whether anyone already has the same username
  $unique = checkDuplicate($_POST['username']);
  if ($unique) {
    $db = new Database('localhost','flashadmin','fortytwo','phpflash');
    $sql = 'INSERT INTO users (first_name,family_name,username,pwd)
       VALUES ("'.$_POST['first_name'].'","'.$_POST['family_name'].'",
       "'.$_POST['username'].'","'.sha1($_POST['pwd']).'")';
    $result = $db->query($sql);
    if ($result) {
      $created = 'Account created for '.$_POST['first_name'].' '.$_POST['family_name'];
      echo 'duplicate=n&message='.urlencode($created);
      }
    }
  }
elseif ($_POST['action'] == 'listAll') {
  // code for retrieving full list
  }
elseif ($_POST['action'] == 'find') {
  // code for search by name, etc
  }
elseif ($_POST['action'] == 'getDetails') {
  // get user details for updating
  }
elseif ($_POST['action'] == 'doUpdate') {
  // update record
  }
elseif ($_POST['action'] == 'doDelete') {
  // delete record
  }
elseif ($_POST['action'] == 'logout') {
  // logout code goes here
  }

// Check for duplicate use of username
function checkDuplicate($username, $user_id = 0) {
  $db = new Database('localhost','flashuser','deepthought','phpflash');
  $sql = "SELECT username FROM users WHERE username = '$username'";
  // add to SQL if user_id supplied as argument
  if ($user_id > 0) {
    $sql .= " AND user_id != $user_id";
    }
  $result = $db->query($sql);
  $numrows = $result->num_rows;
  $db->close();
  
  // if username already in use, send back error message
  if ($numrows > 0) {
    $duplicate = 'Duplicate username. Please choose another.';
    echo 'duplicate=y&message='.urlencode($duplicate);
    exit();
    }
  else {
    return true;
    }
  }
?>