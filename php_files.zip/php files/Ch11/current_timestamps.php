<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Current timestamps</title>
</head>

<body>
<table>
<tr><td><strong>mktime(): </strong></td><td><?php echo mktime(); ?></td></tr>
<tr><td><strong>gmmktime(): </strong></td><td><?php echo gmmktime(); ?></td></tr>
<tr><td><strong>Difference: </strong></td><td><?php echo gmmktime()-mktime(); ?></td></tr>
</table>
</body>
</html>