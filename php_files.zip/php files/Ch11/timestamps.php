<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Timestamp differences</title>
<style type="text/css">
p {width: 600px;margin-left:20px;}
</style>
</head>

<body>
<p><strong>PHP timestamp: </strong><?php echo date('g.i.s a D M j, Y', 1098809520); ?></p>
<p><strong>AS timestamp: </strong> <?php echo date('g.i.s a D M j, Y', 1098809520000); ?></p>
<p><strong>PHP limit - 1: </strong><?php echo date('g.i.s a D M j, Y', 2147483646); ?></p>
<p>Figure 11-2 in the book was created with PHP 5.0.2 on Windows. Later tests on PHP 5.0.3 and PHP 4.3.4 generated a warning indicating that Windows was treating the AS timestamp as negative. Whichever result you get, it proves that using an ActionScript timestamp with PHP won't work. </p>
</body>
</html>
