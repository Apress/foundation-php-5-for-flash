<?php
// following line for use in Windows
setlocale(LC_TIME, 'frc'); 
// if using Mac OS X, comment out the previous line and uncomment the next one
//setlocale(LC_TIME, 'fr_CA'); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Date formats</title>
</head>

<body>
<table>
  <tr>
    <td><strong>date('l, F jS Y g.i a '):</strong></td>
    <td><?php echo date('l, F jS Y g.i a'); ?></td>
  </tr>
  <tr>
    <td><strong>strftime('%A, %d %B %Y %H h %M'):</strong></td>
    <td><?php echo strftime('%A, %d %B %Y %H h %M'); ?></td>
  </tr>
</table>
</body>
</html>
