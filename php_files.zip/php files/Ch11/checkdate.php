<?php
if (isset($_POST['theDate'])) {
  // split the date into component parts
  $theDate = explode('/',$_POST['theDate']);
  // each date part is a string so must first be cast to an integer
  // before it can be passed to the checkdate() function
  $month = (int) $theDate[0];
  $dayNum = (int) $theDate[1];
  $year = (int) $theDate[2];
  // initialize output string to send back to Flash
  $output = 'output=';
  // check the validity of the date
  // if valid, format for MySQL
  if (checkdate($month,$dayNum,$year)) {
    $output .= urlencode('Valid date');
	$output .= "&formatted=$year-$month-$dayNum";
	}
  else {
    $output .= urlencode('Invalid date');
	}
  // send result back to Flash
  echo $output;
  }
?>