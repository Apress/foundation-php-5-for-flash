<?php
echo date('l, F jS, Y');
?>