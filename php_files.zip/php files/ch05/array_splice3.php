<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Demonstration of array_splice()</title>
<style type="text/css">
body {font: 85% Arial, Helvetica, sans-serif;}
h1,h2 {margin-left: 25px;}
h1 {font-size: 140%;}
h2 {font-size: 120%;margin-bottom: 0;}
pre {margin: 5px 60px;}
</style>
</head>

<body>
<h1>Working with array_splice() &#8212; 3</h1>
<h2>Original array</h2>
<?php
$characters = array('Bilbo', 'Frodo', 'Sam', 'Gandalf', 'Arathorn');
echo '<pre>';
print_r($characters);
echo '</pre>';
// removes Frodo, Sam and Gandalf
$removed = array_splice($characters, 1,3);
?>
<h2>After $removed = array_splice($characters, 1,3);</h2>
<?php
echo '<pre>';
print_r($characters);
echo '</pre>';
?>
<h2>$removed now contains a new array</h2>
<?php
echo '<pre>';
print_r($removed);
echo '</pre>';
// restores array to its original form
array_splice($characters, 1, 0, $removed);
?>
<h2>$removed reintegrated using array_splice($characters, 1, 0, $removed);</h2>
<?php
echo '<pre>';
print_r($characters);
echo '</pre>';
?>
</body>
</html>