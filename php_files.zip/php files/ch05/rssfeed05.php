<?php
// reset error reporting to eliminate advisory notices
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT);
require('magpie/rss_fetch.inc');
// set output encoding to Unicode
define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');

// Store feed addresses in array of URLs
$urls[0] = 'http://friendsofed.com/news.php';
$urls[1] = 'http://blogs.apress.com/index.rdf';

$k=0;

// Loop through each address and retrieve RSS feed as object
for ($i = 0; $i < count($urls); $i++) {
  $rss = fetch_rss($urls[$i]);

  // Get channel title and display
  $feed[$i]['title'] = $rss->channel['title'];
  // select first five items of each feed
  $feed[$i]['items'] = array_splice($rss->items,0,5);

  // Nested loop to filter items in each feed into new arrays
  for ($j = 0; $j < count($feed[$i]['items']); $j++, $k++) {
    $channel[$k] = $feed[$i]['title'];
    $title[$k] = $feed[$i]['items'][$j]['title'];
    $description[$k] = $feed[$i]['items'][$j]['description'];
    $link[$k] = $feed[$i]['items'][$j]['link'];
    $date[$k] = substr($feed[$i]['items'][$j]['dc']['date'],0,10);
    $time[$k] = substr($feed[$i]['items'][$j]['dc']['date'],11,8);
    $creator[$k] = isset($feed[$i]['items'][$j]['dc']['creator']) ? $feed[$i]['items'][$j]['dc']['creator'] : '';
    }
  }
// Sort the new arrays according to date and time, latest first
array_multisort($date,SORT_DESC,$time,SORT_DESC,$channel,$title,$description,$link,$creator);
// Display contents of filtered arrays
$output = 'records='.$k;
for ($i=0;$i<count($date);$i++) {
  // Convert date to timestamp and format
  $temp = strtotime($date[$i]);
  $date[$i] = date('D M j', $temp);

  // Create ActionScript variables as nameNumber and URL encode value
  $output .= "&date{$i}=".urlencode($date[$i]);
  $output .= "&channel{$i}=".urlencode($channel[$i]);
  $output .= "&title{$i}=".urlencode($title[$i]);
  $output .= "&description{$i}=".urlencode($description[$i]);
  $output .= "&link{$i}=".urlencode($link[$i]);
  $output .= "&creator{$i}=".urlencode($creator[$i]); 
  }

echo removeCurlyQuotes($output);
function removeCurlyQuotes($string) {
  $curly = array('/%26lsquo%3B/','/%26rsquo%3B/','/%26ldquo%3B/','/%26rdquo%3B/');
  $straight = array('%27','%27','%22','%22');
  $amended = preg_replace($curly,$straight,$string);
  return $amended;
  }
?>