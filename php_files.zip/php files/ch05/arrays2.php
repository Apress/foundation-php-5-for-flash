<?php
$characters[0] = 'Bilbo';
$characters[1] = 'Frodo';
$characters[2] = 'Sam';
$characters[3] = 'Gandalf';
$characters[665] = 'Arathorn';
$characters[] = 'Saruman';

// uncomment the next two lines to add empty elements to the array
// $characters[] = null;  // null is a keyword, so no quotes
// $characters[] = '';

// uncomment the next line to sort the array alphabetically
// sort($characters);
echo '<pre>';
print_r($characters);
// uncomment the next line to see the effect of the sort
// echo $characters[666];
echo '</pre>';
// uncomment the next line to see the length of the array
// echo 'Array length: '.count($characters); 
?>