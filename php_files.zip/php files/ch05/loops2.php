<?php
$characters = array('finder'  => 'Bilbo',
                    'bearer'  => 'Frodo',
					'helper'  => 'Sam',
                    'wizard'  => 'Gandalf',
					'father'  => 'Arathorn',
                    'thepits' => 'Saruman');
// loop through both key (as $role) and value (as $name)
// key and value must be declared in that order
foreach ($characters as $role => $name) {
  // once the key and value have been assigned to temporary variables
  // you can use them any way you like
  echo "$name is $role<br />";
  }
?>