<?php
// reset error reporting to eliminate advisory notices
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT);
require('magpie/rss_fetch.inc');
// set output encoding to Unicode
define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');

// Store feed addresses in array of URLs
$urls[0] = 'http://friendsofed.com/news.php';
$urls[1] = 'http://blogs.apress.com/index.rdf';

// Loop through each address and retrieve RSS feed as object
for ($i=0;$i<count($urls);$i++) {
  $rss = fetch_rss($urls[$i]);
  
  // Get channel title and display
  $feed[$i]['title'] = $rss->channel['title'];
  echo '<h1>'.$feed[$i]['title'].'</h1>';
  // select first five items of each feed
  $feed[$i]['items'] = array_splice($rss->items,0,5);
  // Loop through array of items in each feed
  for ($j = 0 ; $j < count($feed[$i]['items']); $j++) {
    echo $feed[$i]['items'][$j]['title'].'<br />';
    }
  }

// Display content of object
/*echo '<pre>';
print_r($rss);
echo '</pre>';*/
?>