<?php
$characters = array('Bilbo', 'Frodo', 'Sam', 'Gandalf', 'Arathorn', 'Saruman');
for ($i = 0; $i < count($characters); $i++) {
  echo $characters[$i].'<br />';
  }
?>