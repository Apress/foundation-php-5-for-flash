<?php
// indexed array (numbers used for keys)
$characters[0] = 'Bilbo';
$characters[1] = 'Frodo';
$characters[2] = 'Sam';
$characters[3] = 'Gandalf';
$characters[665] = 'Arathorn';
$characters[] = 'Saruman';

// associative array (strings used for keys)
$characters['finder']  = 'Bilbo';
$characters['bearer']  = 'Frodo';
$characters['helper']  = 'Sam';
$characters['wizard']  = 'Gandalf';
$characters['father']  = 'Arathorn';
$characters['thepits'] = 'Saruman';

// uncomment the next line to sort the array alphabetically
// sort($characters);
// uncomment the next line to sort the array by value
// asort($characters);
// uncomment the next line to sort the array by key
ksort($characters);
echo '<pre>';
print_r($characters);
echo '</pre>';
echo 'Array length: '.count($characters); 
// uncomment the next line to display value of associative element
// echo $characters['finder'];
?>