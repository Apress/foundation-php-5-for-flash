<?php
$characters = array('finder'  => 'Bilbo',
                    'bearer'  => 'Frodo',
					'helper'  => 'Sam',
                    'wizard'  => 'Gandalf',
					'father'  => 'Arathorn',
                    'thepits' => 'Saruman');
// loop through each value, using $character as a temporary variable
foreach ($characters as $character) {
  echo "$character<br />";
  }
?>