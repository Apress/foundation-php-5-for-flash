<?php
$i = 1;
for ($j = 1; $j <=12; $j++) {
  echo "$i x $j = ".$i*$j.'<br />';
  }
?>