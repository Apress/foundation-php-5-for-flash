<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Demonstration of array_splice()</title>
<style type="text/css">
body {font: 85% Arial, Helvetica, sans-serif;}
h1,h2 {margin: 5px auto 5px 25px;}
h1 {font-size: 140%;}
h2 {font-size: 85%;}
pre {margin: 5px 60px;}
</style>
</head>

<body>
<?php
$cast = array('finder' => 'Bilbo', 'bearer' => 'Frodo', 'helper' => 'Sam',
'wizard' => 'Gandalf', 'father' => 'Arathorn', 'thepits' => 'Saruman');
?>
<h1>ksort($cast)</h1>
<h2>sorted by key</h2>
<?php
ksort($cast);
echo '<pre>';
print_r($cast);
echo '</pre>';
?>
<h1>krsort($cast)</h1>
<h2>sorted by key&#8212;reverse order</h2>
<?php
krsort($cast);
echo '<pre>';
print_r($cast);
echo '</pre>';
?>
<h1>asort($cast)</h1>
<h2>sorted by value</h2>
<?php
asort($cast);
echo '<pre>';
print_r($cast);
echo '</pre>';
?>
<h1>arsort($cast)</h1>
<h2>sorted by value&#8212;reverse order</h2>
<?php
arsort($cast);
echo '<pre>';
print_r($cast);
echo '</pre>';
?>
</body>
</html>