<?php
$characters = array('Bilbo', 'Frodo', 'Sam', 'Gandalf', 'Arathorn');
$goodguys = array_splice($characters, 3);
echo '<pre>';
print_r($goodguys);
print_r($characters);
echo '</pre>';
?>