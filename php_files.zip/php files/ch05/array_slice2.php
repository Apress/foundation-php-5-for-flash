<?php
$characters = array('Bilbo', 'Frodo', 'Sam', 'Gandalf', 'Arathorn');
$theOne = array_slice($characters, 1, -3);
$thePositiveOne = array_slice($characters, 1, 1);
// display both results and the original array
echo '<pre>';
print_r($theOne);
print_r($thePositiveOne);
print_r($characters);
echo '<pre>';
?>