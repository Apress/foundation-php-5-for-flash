<?php
$characters = array('finder'  => 'Bilbo',
                    'bearer'  => 'Frodo',
                    'helper'  => 'Sam',
                    'wizard'  => 'Gandalf',
                    'father'  => 'Arathorn',
                    'thepits' => 'Saruman');
// the following loop won't work
// because $characters is an associative array
// you must use a foreach loop as in loops1.php
for ($i = 0; $i < count($characters); $i++) {
  echo $characters[$i].'<br />';
  }
?>