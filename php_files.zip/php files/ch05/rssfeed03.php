<?php
// reset error reporting to eliminate advisory notices
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT);
require('magpie/rss_fetch.inc');
define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');

// Store feed addresses in array of URLs
$urls[0] = 'http://friendsofed.com/news.php';
$urls[1] = 'http://blogs.apress.com/index.rdf';

$k=0;

// Loop through each address and retrieve RSS feed as object
for ($i = 0; $i < count($urls); $i++) {
  $rss = fetch_rss($urls[$i]);

  // Get channel title and display
  $feed[$i]['title'] = $rss->channel['title'];
  // select first five items of each feed
  $feed[$i]['items'] = array_splice($rss->items,0,5);

  // Nested loop to filter items in each feed into new arrays
  for ($j = 0; $j < count($feed[$i]['items']); $j++, $k++) {
    $channel[$k] = $feed[$i]['title'];
    $title[$k] = $feed[$i]['items'][$j]['title'];
    $description[$k] = $feed[$i]['items'][$j]['description'];
    $link[$k] = $feed[$i]['items'][$j]['link'];
    $date[$k] = substr($feed[$i]['items'][$j]['dc']['date'],0,10);
    $time[$k] = substr($feed[$i]['items'][$j]['dc']['date'],11,8);
    $creator[$k] = isset($feed[$i]['items'][$j]['dc']['creator']) ? $feed[$i]['items'][$j]['dc']['creator'] : '';
    }
  }

// Display contents of filtered arrays
echo '<pre>';
print_r($channel);
print_r($title);
print_r($description);
print_r($link);
print_r($date);
print_r($time);
print_r($creator);
echo '</pre>';
?>