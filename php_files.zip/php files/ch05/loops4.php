<?php
// each time the loop executes, $i is incremented by 20 and $j decremented by 2
// the loop stops when $i reaches 100 (by which time $j is 90)
for ($i = 0, $j = 100; $i <= 100; $i += 20, $j -= 2) {
  echo "\$i is $i; \$j is $j<br />";
  }
?>