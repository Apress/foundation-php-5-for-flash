<?php
// reset error reporting to eliminate advisory notices
error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT);
require('magpie/rss_fetch.inc');
// set output encoding to Unicode
define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');

// Store feed addresses in array of URLs
$urls[0] = 'http://friendsofed.com/news.php';

// Loop through each address and retrieve RSS feed as object
for ($i=0;$i<count($urls);$i++) {
  $rss = fetch_rss($urls[$i]);
  }

// Display content of object
echo '<pre>';
print_r($rss);
echo '</pre>';
?>