<?php
$characters = array('Bilbo', 'Frodo', 'Sam', 'Gandalf', 'Arathorn');
// start index is 3 - in other words the fourth item
// no end index, so it extracts to the end of the array
$goodguys = array_slice($characters, 3);
// start index is negative, so it counts from the end of the array
// and extracts from that point
// again no end index, so extracts to the end of the array
$goodguys2 = array_slice($characters, -2);
// display both results and the original array
echo '<pre>';
print_r($goodguys);
print_r($goodguys2);
print_r($characters);
echo '<pre>';
?>