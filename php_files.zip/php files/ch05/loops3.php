<?php
// a for loop takes three arguments:
// * an initial counter
// * a test that determines whether the loop should continue to run
// * the amount by which the counter should be incremented each time
// this displayes all numbers from 0 through 100
for ($i = 0; $i <= 100; $i++) {
  echo $i.'<br />';
  }
?>