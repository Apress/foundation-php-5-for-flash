<?php
// indexed array (numbers used for keys)
$characters = array('Bilbo', 'Frodo', 'Sam');
$characters[] = 'Gandalf';
$characters[665] = 'Arathorn';
$characters[] = 'Saruman';

// associative array (strings used for keys)
$characters = array('finder'  => 'Bilbo',
                    'bearer'  => 'Frodo',
                    'helper'  => 'Sam',
                    'wizard'  => 'Gandalf',
                    'father'  => 'Arathorn',
                    'thepits' => 'Saruman');

// uncomment the next line to overwrite the new array
// $characters = array();

// uncomment the next line to sort the array using the keys
// ksort($characters);
// uncomment the next line to sort the array using the values
// asort($characters);
echo '<pre>';
print_r($characters);
echo '</pre>';
echo 'Array length: '.count($characters); 
?>