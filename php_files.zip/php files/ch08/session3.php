<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Session test - 3</title>
</head>

<body>
<?php
// check whether session variable is set
if (isset($_SESSION['name'])) {
  // if set, greet by name
  echo '<p>I remember you. It\'s '.$_SESSION['name'].', isn\'t it? <a href="session2.php">Page 2</a></p>';
  // unset the session variable
  unset($_SESSION['name']);
  // destroy the session
  session_destroy();
  }
else {
  // if not set, send back to login page
  echo '<p>Not authorized. <a href="session_login.php">Please log in.</a></p>';
  }
?>
</body>
</html>
