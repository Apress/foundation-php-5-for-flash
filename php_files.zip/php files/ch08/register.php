<?php
// include the Database classes
require_once('../classes/database.php');

// escape quotes and apostrophes if magic_quotes_gpc off
if (!get_magic_quotes_gpc()) {
  foreach($_POST as $key=>$value) {
    $temp = addslashes($value);
    $_POST[$key] = $temp;
    }
  }

// create a Database instance and check username
$db = new Database('localhost','flashadmin','fortytwo','phpflash');
$sql = 'SELECT username FROM users WHERE username = "'.$_POST['username'].'"';
$result = $db->query($sql);
$numrows = $result->num_rows;

// if username already in use, send back error message
if ($numrows > 0) {
  $duplicate = 'Duplicate username. Please choose another.';
  echo 'duplicate=y&message='.urlencode($duplicate);
  }
else { // insert the data into the users table
  $sql = 'INSERT INTO users (first_name,family_name,username,pwd)
          VALUES ("'.$_POST['first_name'].'","'.$_POST['family_name'].'",
          "'.$_POST['username'].'","'.sha1($_POST['pwd']).'")';
  $result = $db->query($sql);
  if ($result) {
    $created = 'Account created for '.$_POST['username'];
    echo 'duplicate=n&message='.urlencode($created);
    }
  }
?>