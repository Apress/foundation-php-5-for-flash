<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>register_user</title>
</head>
<body bgcolor="#ffffff">
<?php
if (isset($_SESSION['authenticated'])) {
?>
<!--url's used in the movie-->
<!--text used in the movie-->
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="550" height="400" id="register_user" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="register_user.swf" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="register_user.swf" quality="high" bgcolor="#ffffff" width="550" height="400" name="register_user" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
<p><a href="logout.php">Log out</a></p>
<?php
  }
else {
  echo '<p><a href="login.html">Please log in</a></p>';
  }
?>
</body>
</html>
